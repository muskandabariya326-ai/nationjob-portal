/* NATIONJOB public configuration.
 * Supabase publishable/anon key is browser-visible by design. Enforce RLS.
 * Never put a service_role key or other secret in this file.
 */
window.NATIONJOB_CONFIG = {
  supabaseUrl: "https://YOUR-PROJECT.supabase.co",
  supabaseAnonKey: "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY",
  siteUrl: "https://YOUR-REGISTERED-DOMAIN",
  demoMode: true
};
