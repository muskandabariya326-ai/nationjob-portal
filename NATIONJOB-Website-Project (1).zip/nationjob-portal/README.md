# NATIONJOB – Central Government Recruitment Portal

A responsive bilingual (English/Hindi) recruitment information portal starter built for Google Firebase Hosting, with a Supabase/PostgreSQL backend integration path.

> **Important:** This project is a deployable website starter, not an already-published website. It includes a working local preview, frontend interactions, Firebase Hosting configuration, a production database schema and setup instructions. It does not include a purchased domain, a Firebase project, Supabase credentials, a live government-recruitment feed, legal review, or an independently verified production dataset. The preview vacancy cards are deliberately marked as **demo records** and are not real jobs.

## What is included

- Premium responsive NATIONJOB public portal.
- English/Hindi language toggle (the main homepage interface and recruitment title fields support switching; editorial content and translations should be reviewed/expanded before launch).
- Search, qualification and department filters, status tabs and sort controls.
- Vacancy detail modal with official-source destination, important dates, qualification, age, salary and selection-process fields.
- Local bookmarks and personal application tracker in preview; Supabase-backed bookmarks, tracker entries and alert preferences when live mode is configured.
- Preliminary eligibility comparison and age calculator (not an official decision).
- Admit card, results, answer-key and calendar views, ready to read verified records from Supabase.
- Admin demo: create/edit local preview records; records remain local and visibly unverified. Live admin tools include recruitment drafts, source evidence, PDF archive upload, verification review, exam-update publishing and correction-report triage when configured.
- Supabase integration path for accounts, organizations, jobs, translations, source records, reviewer verification, user bookmarks, application notes, notification preferences, examination updates and correction reports.
- PostgreSQL schema with row-level security (RLS), role checks, audit records and verification guards.
- Firebase Hosting configuration, 404 page, privacy/terms/disclaimer templates, robots.txt, sitemap.xml and PWA manifest.

## Folder structure

```text
nationjob-portal/
├── firebase.json
├── .firebaserc.example
├── README.md
├── public/
│   ├── index.html
│   ├── app.js
│   ├── styles.css
│   ├── config.js
│   ├── 404.html
│   ├── privacy.html
│   ├── terms.html
│   ├── disclaimer.html
│   ├── robots.txt
│   ├── sitemap.xml
│   ├── manifest.webmanifest
│   └── assets/favicon.svg
├── supabase/schema.sql
└── docs/LAUNCH-CHECKLIST.md
```

## 1. Preview locally

The website is static and does not require a build step.

### Windows

1. Extract the ZIP.
2. Open the extracted `nationjob-portal` folder.
3. Open PowerShell in that folder.
4. Run:

```powershell
python -m http.server 8080 --directory public
```

5. Open `http://localhost:8080` in a browser.

If Python is not installed, use an equivalent static web server. Opening `index.html` directly may limit browser storage or clipboard functionality.

## 2. Deploy to Google Firebase Hosting

Firebase Hosting is the included hosting target. Its official quickstart uses a Firebase project, the Firebase CLI, a `public` directory and `firebase deploy --only hosting`.

1. Create a Firebase project at https://console.firebase.google.com/.
2. Install Node.js (LTS) and the Firebase CLI:

```bash
npm install -g firebase-tools
```

3. Sign in:

```bash
firebase login
```

4. Extract this project and open a terminal in the `nationjob-portal` root directory.
5. Copy `.firebaserc.example` to `.firebaserc` and replace `YOUR_FIREBASE_PROJECT_ID` with your actual Firebase project ID. Or run `firebase use --add` and select your project.
6. Deploy the static website:

```bash
firebase deploy --only hosting
```

7. Firebase will provide a project URL on `web.app` and `firebaseapp.com`. Test it before connecting a custom domain.

Official guides:
- Firebase Hosting quickstart: https://firebase.google.com/docs/hosting/quickstart
- Firebase Hosting overview: https://firebase.google.com/docs/hosting/
- Custom domain setup: https://firebase.google.com/docs/hosting/custom-domain

## 3. Connect a custom domain

Suggested names to check with a domain registrar:

- `nationjob.in` – first choice, subject to availability and trademark review.
- `nationjob.co.in` – alternative, subject to availability.
- `nationjob.net` – alternative, subject to availability.

**Domain availability has not been confirmed and no domain has been purchased.** Search the exact name at a registrar and check trademark/name conflicts before paying. Do not use a `.gov.in` domain; that namespace is intended for eligible government entities, not an independent information portal.

In Firebase Console → Hosting → Add custom domain, enter the domain you purchased and follow the ownership verification and DNS-record instructions shown by Firebase. Do not copy DNS values from an example; use the exact records Firebase gives to your domain provider. Firebase provisions SSL for connected domains after verification and DNS setup.

After connecting your domain, replace `YOUR-DOMAIN.example` in:
- `public/config.js` (`siteUrl`)
- `public/index.html` (canonical URL)
- `public/robots.txt` (sitemap URL)
- `public/sitemap.xml` (all `<loc>` values)

## 4. Configure Supabase for live data and accounts

The website defaults to demo mode. This is intentional so example recruitment records cannot be mistaken for live government vacancies.

1. Create a Supabase project at https://supabase.com/.
2. Open SQL Editor and run `supabase/schema.sql`.
3. Create a private Storage bucket named `job-documents`. Keep original files private unless you deliberately design a controlled public-download flow. Do not upload candidate identity documents.
4. In Supabase project settings, copy the Project URL and browser-safe publishable/anon key.
5. Edit `public/config.js`:

```js
window.NATIONJOB_CONFIG = {
  supabaseUrl: "https://YOUR-PROJECT.supabase.co",
  supabaseAnonKey: "YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY",
  siteUrl: "https://YOUR-REGISTERED-DOMAIN",
  demoMode: false
};
```

6. The Supabase browser publishable/anon key is not a secret. Database security depends on correctly applied RLS policies. **Never place a Supabase `service_role` key in `public/config.js`, HTML, JavaScript or any browser file.**
7. Create your first account using the site's sign-in modal. In Supabase Authentication, confirm the account if email confirmation is enabled.
8. Find that user's UUID in Authentication → Users. In SQL Editor, assign the initial role once:

```sql
update public.profiles
set role = 'super_admin'
where id = 'YOUR-AUTH-USER-UUID';
```

9. Sign in again, then create recruiting organizations and draft recruitment records. An editor can add drafts and source references. A separate authorized verification officer/admin must review the source evidence and verify the record before the public jobs query displays it.
10. Assign staff roles using a super-admin-only process. Do not give all editors verification rights.

### Live-data safety rules

- Do not publish sample records from demo mode.
- Only mark a vacancy verified after checking the original recruitment notification and the official recruitment page.
- Verify notification number, exact posts, vacancy count, qualification, subject/experience, age, relaxation, date cutoff, fee, salary/pay level, selection stages, application URL and all corrigenda.
- Store evidence notes, reviewer, source URL and verification timestamp.
- A hash change or broken link is a review signal, not automatic proof that a notice changed.
- Avoid scraping sites where access terms prohibit it. Prefer official feeds, permitted APIs, email notices or human review.
- The project does not contain an official automatic government data feed. Banking and other non-ministerial hiring must be categorized and labelled accurately rather than implied to be a ministry recruitment.

## 5. Search engine setup

After deployment on the real domain:

1. Verify domain ownership in Google Search Console.
2. Replace the sitemap domain placeholder and publish `https://YOUR-REGISTERED-DOMAIN/sitemap.xml`.
3. Submit the sitemap in Search Console. Submission is a discovery hint, not a guarantee of indexing.
4. Keep canonical URLs, titles, descriptions and translated page URLs consistent.
5. Only use `JobPosting` structured data on qualifying individual live job-detail pages, with accurate information. Do not mark category pages or expired demo vacancies as live jobs.
6. Remove placeholder/demo pages from production indexing or keep demo records out of the live database.

Official Google sitemap guidance: https://developers.google.com/search/docs/crawling-indexing/sitemaps/build-sitemap

## 6. Before public launch

Use `docs/LAUNCH-CHECKLIST.md`. In particular, replace all domain placeholders, complete legal policy review, set up role permissions, test RLS, set a verified support contact, configure backups/monitoring, and load only verified real notices.

## 7. Current implementation limits (be transparent)

- This package is a deployable static frontend and backend integration starter; it has not been connected to your Firebase or Supabase accounts.
- No domain has been purchased or connected.
- Sample vacancies are demonstrations only.
- The homepage and primary public sections have English/Hindi switching, and recruitment records support separate English/Hindi title and summary fields. Before launch, a Hindi editor should complete and review every editorial string, administrative message and recruitment translation.
- User bookmarks and application tracker entries work in browser storage in preview mode. The database schema includes user tables; configure and test authenticated synchronization and notification delivery before promising cross-device sync or email alerts.
- Document storage bucket setup and document upload/download workflows require the separate storage configuration described above.
- A background schedule/worker for monitoring official notices and date expirations must be configured before advertising automatic update alerts.
- This repository does not provide legal advice, government affiliation, guaranteed eligibility results or automatic recruitment verification.

## 8. Project checks

- JavaScript syntax: `node --check public/app.js`
- Preview: `python -m http.server 8080 --directory public`
- Firebase deployment: `firebase deploy --only hosting`
