# NATIONJOB production launch checklist

## Identity and domain
- [ ] Confirm the actual website operator's legal name and support contact.
- [ ] Check domain availability and name/trademark conflicts; register the chosen domain.
- [ ] Create a Firebase project and connect Firebase Hosting.
- [ ] Add the custom domain in Firebase and apply the exact DNS records shown in console.
- [ ] Replace every `YOUR-DOMAIN.example` placeholder.
- [ ] Verify HTTPS and redirects for apex and `www` hostnames.

## Data and editorial operations
- [ ] Create the Supabase project and apply `supabase/schema.sql`.
- [ ] Create the private `job-documents` Storage bucket and inspect access policies.
- [ ] Configure the public project URL and anon/publishable key in `public/config.js`.
- [ ] Set `demoMode: false` only after the verified source workflow is ready.
- [ ] Create the initial super-admin account; assign the role by UUID in SQL.
- [ ] Create at least two staff accounts: recruitment editor and verification officer.
- [ ] Test role separation: editors create drafts; only reviewers verify.
- [ ] Verify RLS with anonymous, normal-user, editor, reviewer and admin test accounts.
- [ ] Create organization records with official HTTPS websites.
- [ ] Publish no vacancy until the original official notice has been checked.
- [ ] Check notification number, exact post, vacancies, qualification, age, relaxation, dates, fee, pay, selection, official application URL and corrigenda.
- [ ] Add checked-by, checked-at and evidence notes for every verified item.
- [ ] Review Hindi copy independently; mark translation status correctly.
- [ ] Add a process for closed, cancelled, extended and amended vacancies.

## Functionality
- [ ] Test search, qualification filters, department filters, status tabs and sort.
- [ ] Test job details and official-source destinations on mobile and desktop.
- [ ] Test bookmarks for signed-out and signed-in users.
- [ ] Test user application tracker privacy.
- [ ] Test eligibility calculator boundaries, cutoff dates and missing data.
- [ ] Test age calculator leap years and dates before birth.
- [ ] Test admit cards, results, answer keys and calendar from verified exam update data.
- [ ] Test source correction/report form and staff triage process.
- [ ] Test account sign-up, confirmation, sign-in, sign-out and deletion.
- [ ] Configure and test email notifications before advertising alerts.
- [ ] Configure official-notice monitoring/background jobs before advertising automatic monitoring.

## Quality, security and legal
- [ ] Test keyboard access, screen reader labels, contrast and reduced motion.
- [ ] Test 360px mobile, tablet, laptop and wide desktop layouts.
- [ ] Test current Chrome, Edge, Firefox and Safari.
- [ ] Set up database backups and perform a restore drill.
- [ ] Configure error monitoring and uptime alerts.
- [ ] Configure rate limits and spam protections for public reports/authentication.
- [ ] Review security headers and Content Security Policy.
- [ ] Conduct an RLS and application security review.
- [ ] Review Privacy Policy, Terms and Disclaimer with a qualified professional.
- [ ] Add an operator contact and correction/report response process.
- [ ] Ensure no government logos or wording imply official affiliation.
- [ ] Check all third-party assets and content permissions.

## Google Search and launch
- [ ] Replace canonical URLs in `index.html`.
- [ ] Replace sitemap domain placeholders.
- [ ] Review `robots.txt` and sitemap.
- [ ] Configure Google Search Console and verify domain ownership.
- [ ] Submit sitemap after launch.
- [ ] Validate structured data only for real eligible individual job pages.
- [ ] Do not index demo records as live vacancies.
- [ ] Confirm contact details, policies, source links and first verified notices.
- [ ] Announce the site only after all critical checks are complete.
