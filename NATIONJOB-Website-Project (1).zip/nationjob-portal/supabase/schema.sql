-- NATIONJOB production schema (PostgreSQL / Supabase)
-- Apply in Supabase SQL Editor. Review policies with a database professional before launch.

create extension if not exists pgcrypto;

-- 1) Roles and profiles -------------------------------------------------------
do $$ begin
  create type public.user_role as enum (
    'user', 'analyst', 'support_officer', 'hindi_editor',
    'content_reviewer', 'recruitment_editor', 'verification_officer',
    'admin', 'super_admin'
  );
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.job_status as enum ('draft','upcoming','open','closed','cancelled','on_hold');
exception when duplicate_object then null; end $$;

do $$ begin
  create type public.verification_status as enum ('pending','in_review','verified','rejected','reverification_required');
exception when duplicate_object then null; end $$;

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  preferred_language text not null default 'en' check (preferred_language in ('en','hi')),
  role public.user_role not null default 'user',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public
as $$ begin
  insert into public.profiles(id, display_name, preferred_language, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'name',''),
          coalesce(new.raw_user_meta_data->>'preferred_language','en'), 'user')
  on conflict (id) do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users
for each row execute procedure public.handle_new_user();

create or replace function public.current_user_role()
returns text language sql stable security definer set search_path = public
as $$ select coalesce((select role::text from public.profiles where id = auth.uid()), 'anonymous'); $$;

create or replace function public.has_any_role(allowed text[])
returns boolean language sql stable security definer set search_path = public
as $$ select public.current_user_role() = any(allowed); $$;

-- 2) Organizations and recruitment records ----------------------------------
create table if not exists public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  slug text not null unique,
  official_website text not null check (official_website ~ '^https://'),
  organization_type text not null default 'Central Government organization',
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.jobs (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete restrict,
  slug text not null unique,
  reference_number text,
  title text not null,
  status public.job_status not null default 'draft',
  verification_status public.verification_status not null default 'pending',
  vacancy_count integer check (vacancy_count is null or vacancy_count >= 0),
  job_type text,
  location text,
  notification_date date,
  application_start_at timestamptz,
  application_end_at timestamptz,
  minimum_qualification text,
  age_min integer check (age_min is null or age_min >= 0),
  age_max integer check (age_max is null or age_max >= 0),
  salary text,
  selection_process text,
  summary text,
  created_by uuid references auth.users(id) on delete set null,
  updated_by uuid references auth.users(id) on delete set null,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  check (age_min is null or age_max is null or age_max >= age_min),
  check (application_start_at is null or application_end_at is null or application_end_at >= application_start_at)
);

create table if not exists public.job_translations (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  language_code text not null check (language_code in ('en','hi')),
  title text not null,
  summary text,
  qualification_text text,
  selection_process text,
  application_instructions text,
  translation_status text not null default 'draft' check (translation_status in ('draft','review','approved')),
  reviewed_by uuid references auth.users(id) on delete set null,
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique(job_id, language_code)
);

create or replace function public.flag_translation_reverification()
returns trigger language plpgsql security definer set search_path = public
as $$
declare parent_job_id uuid;
begin
  parent_job_id := coalesce(NEW.job_id, OLD.job_id);
  update public.jobs
    set verification_status = 'reverification_required', published_at = null, updated_at = now()
    where id = parent_job_id and verification_status = 'verified';
  if TG_OP = 'DELETE' then return OLD; else return NEW; end if;
end; $$;
drop trigger if exists translation_change_reverification on public.job_translations;
create trigger translation_change_reverification
after insert or update or delete on public.job_translations
for each row execute procedure public.flag_translation_reverification();

create table if not exists public.job_qualifications (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  qualification_code text not null,
  qualification_label text not null,
  subject_or_stream text,
  minimum_marks numeric(5,2),
  completion_cutoff date,
  notes text,
  created_at timestamptz not null default now()
);

create table if not exists public.job_age_rules (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  category_code text,
  minimum_age integer,
  maximum_age integer,
  relaxation_years integer not null default 0 check (relaxation_years >= 0),
  cutoff_date date,
  rule_text text,
  source_id uuid,
  created_at timestamptz not null default now()
);

create table if not exists public.job_dates (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  date_type text not null check (date_type in ('notification','application_start','application_end','fee_deadline','correction_start','correction_end','exam','interview','other')),
  date_value timestamptz not null,
  is_confirmed boolean not null default false,
  source_id uuid,
  note text,
  created_at timestamptz not null default now()
);

-- 3) Sources, documents and verification ------------------------------------
create table if not exists public.job_sources (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  source_url text not null check (source_url ~ '^https://'),
  source_type text not null check (source_type in ('official_notification','recruitment_portal','organization_website','corrigendum','result','admit_card','other_official')),
  source_label text,
  document_sha256 text,
  last_checked_at timestamptz,
  checked_by uuid references auth.users(id) on delete set null,
  evidence_notes text,
  created_at timestamptz not null default now()
);

alter table public.job_age_rules drop constraint if exists job_age_rules_source_id_fkey;
alter table public.job_age_rules add constraint job_age_rules_source_id_fkey foreign key (source_id) references public.job_sources(id) on delete set null;
alter table public.job_dates drop constraint if exists job_dates_source_id_fkey;
alter table public.job_dates add constraint job_dates_source_id_fkey foreign key (source_id) references public.job_sources(id) on delete set null;

create table if not exists public.job_documents (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  document_type text not null check (document_type in ('notification','corrigendum','syllabus','exam_pattern','answer_key','result','admit_card','other')),
  storage_path text,
  original_url text check (original_url is null or original_url ~ '^https://'),
  sha256_hash text,
  language_code text check (language_code is null or language_code in ('en','hi')),
  is_public boolean not null default false,
  uploaded_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.verification_records (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  source_id uuid references public.job_sources(id) on delete set null,
  reviewer_id uuid not null references auth.users(id) on delete restrict,
  status public.verification_status not null,
  evidence_notes text not null,
  verified_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.job_updates (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  update_type text not null check (update_type in ('corrigendum','date_extension','vacancy_change','eligibility_change','cancellation','reopening','other')),
  summary text not null,
  source_id uuid references public.job_sources(id) on delete set null,
  changed_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

create table if not exists public.exam_updates (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.jobs(id) on delete cascade,
  update_type text not null check (update_type in ('admit_card','result','answer_key','exam_date','interview_call','other')),
  title text not null,
  language_code text not null default 'en' check (language_code in ('en','hi')),
  official_url text not null check (official_url ~ '^https://'),
  published_at timestamptz,
  is_verified boolean not null default false,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now()
);

-- 4) User features ------------------------------------------------------------
create table if not exists public.saved_jobs (
  user_id uuid not null references auth.users(id) on delete cascade,
  job_id uuid not null references public.jobs(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key(user_id, job_id)
);

create table if not exists public.applications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  job_id uuid references public.jobs(id) on delete set null,
  recruitment_title text not null,
  personal_status text not null check (personal_status in ('planning','applied','admit_card','exam_completed','result_checked','withdrawn')),
  private_notes text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.notification_preferences (
  user_id uuid primary key references auth.users(id) on delete cascade,
  email_enabled boolean not null default false,
  language_code text not null default 'en' check (language_code in ('en','hi')),
  qualification_codes text[] not null default '{}',
  department_slugs text[] not null default '{}',
  updated_at timestamptz not null default now()
);

create table if not exists public.notification_deliveries (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  job_id uuid references public.jobs(id) on delete cascade,
  notification_type text not null,
  delivery_status text not null default 'queued',
  delivered_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists public.content_reports (
  id uuid primary key default gen_random_uuid(),
  job_id uuid references public.jobs(id) on delete set null,
  page_url text,
  report_type text not null,
  message text not null,
  contact_email text,
  status text not null default 'open' check (status in ('open','in_review','resolved','dismissed')),
  created_at timestamptz not null default now()
);

create table if not exists public.admin_audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references auth.users(id) on delete set null,
  action text not null,
  target_type text not null,
  target_id uuid,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

-- 5) Guard privilege changes and verified status changes ---------------------
create or replace function public.guard_profile_role_change()
returns trigger language plpgsql security definer set search_path = public
as $$ begin
  if NEW.role is distinct from OLD.role and auth.uid() is not null and not public.has_any_role(array['super_admin']) then
    raise exception 'Only a super administrator may change account roles';
  end if;
  NEW.updated_at = now();
  return NEW;
end; $$;
drop trigger if exists profiles_role_guard on public.profiles;
create trigger profiles_role_guard before update on public.profiles
for each row execute procedure public.guard_profile_role_change();

create or replace function public.guard_exam_update_verification()
returns trigger language plpgsql security definer set search_path = public
as $$ begin
  if NEW.is_verified is distinct from OLD.is_verified and NEW.is_verified = true
     and not public.has_any_role(array['super_admin','admin','verification_officer']) then
    raise exception 'Only an authorized verification reviewer may verify an exam update';
  end if;
  return NEW;
end; $$;
drop trigger if exists exam_update_verification_guard on public.exam_updates;
create trigger exam_update_verification_guard before update on public.exam_updates
for each row execute procedure public.guard_exam_update_verification();

create or replace function public.guard_job_verification()
returns trigger language plpgsql security definer set search_path = public
as $$
begin
  if TG_OP = 'INSERT' and NEW.verification_status = 'verified'
     and not public.has_any_role(array['super_admin','admin','verification_officer']) then
    raise exception 'Only authorized verification reviewers may create a verified record';
  end if;
  if TG_OP = 'UPDATE' and NEW.verification_status is distinct from OLD.verification_status
     and NEW.verification_status = 'verified'
     and not public.has_any_role(array['super_admin','admin','verification_officer']) then
    raise exception 'Only authorized verification reviewers may verify a recruitment record';
  end if;
  -- Material edits to a verified vacancy automatically remove its public verified state.
  -- A reviewer must re-check sources and explicitly verify it again.
  if TG_OP = 'UPDATE' and OLD.verification_status = 'verified' and (
    NEW.organization_id is distinct from OLD.organization_id OR
    NEW.reference_number is distinct from OLD.reference_number OR
    NEW.title is distinct from OLD.title OR
    NEW.vacancy_count is distinct from OLD.vacancy_count OR
    NEW.job_type is distinct from OLD.job_type OR
    NEW.location is distinct from OLD.location OR
    NEW.notification_date is distinct from OLD.notification_date OR
    NEW.application_start_at is distinct from OLD.application_start_at OR
    NEW.application_end_at is distinct from OLD.application_end_at OR
    NEW.minimum_qualification is distinct from OLD.minimum_qualification OR
    NEW.age_min is distinct from OLD.age_min OR NEW.age_max is distinct from OLD.age_max OR
    NEW.salary is distinct from OLD.salary OR
    NEW.selection_process is distinct from OLD.selection_process OR
    NEW.summary is distinct from OLD.summary
  ) THEN
    NEW.verification_status := 'reverification_required';
    NEW.published_at := null;
  END IF;
  NEW.updated_at = now();
  return NEW;
end; $$;
drop trigger if exists jobs_verification_guard on public.jobs;
create trigger jobs_verification_guard before insert or update on public.jobs
for each row execute procedure public.guard_job_verification();

-- 6) Indexes -----------------------------------------------------------------
create index if not exists jobs_public_status_idx on public.jobs(status, verification_status, notification_date desc);
create index if not exists jobs_org_idx on public.jobs(organization_id);
create index if not exists jobs_end_date_idx on public.jobs(application_end_at);
create index if not exists jobs_qualification_idx on public.jobs(minimum_qualification);
create index if not exists sources_job_idx on public.job_sources(job_id);
create index if not exists verification_job_idx on public.verification_records(job_id, created_at desc);
create index if not exists exam_updates_type_idx on public.exam_updates(update_type, published_at desc);
create index if not exists job_translations_search_idx on public.job_translations using gin (to_tsvector('simple', coalesce(title,'') || ' ' || coalesce(summary,'')));

-- 7) Row-level security -------------------------------------------------------
alter table public.profiles enable row level security;
alter table public.organizations enable row level security;
alter table public.jobs enable row level security;
alter table public.job_translations enable row level security;
alter table public.job_qualifications enable row level security;
alter table public.job_age_rules enable row level security;
alter table public.job_dates enable row level security;
alter table public.job_sources enable row level security;
alter table public.job_documents enable row level security;
alter table public.verification_records enable row level security;
alter table public.job_updates enable row level security;
alter table public.exam_updates enable row level security;
alter table public.saved_jobs enable row level security;
alter table public.applications enable row level security;
alter table public.notification_preferences enable row level security;
alter table public.notification_deliveries enable row level security;
alter table public.content_reports enable row level security;
alter table public.admin_audit_logs enable row level security;

-- Profiles: users can view/update only their own basic profile. Role changes are admin-only.
drop policy if exists profile_select_self on public.profiles;
create policy profile_select_self on public.profiles for select to authenticated using (id = auth.uid() or public.has_any_role(array['super_admin','admin']));
drop policy if exists profile_update_self on public.profiles;
create policy profile_update_self on public.profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
drop policy if exists profile_admin_update on public.profiles;
create policy profile_admin_update on public.profiles for update to authenticated using (public.has_any_role(array['super_admin'])) with check (public.has_any_role(array['super_admin']));

-- Organization names and approved sites are publicly readable.
drop policy if exists organizations_public_read on public.organizations;
create policy organizations_public_read on public.organizations for select to anon, authenticated using (is_active = true or public.has_any_role(array['super_admin','admin','recruitment_editor']));
drop policy if exists organizations_editor_insert on public.organizations;
create policy organizations_editor_insert on public.organizations for insert to authenticated with check (public.has_any_role(array['super_admin','admin','recruitment_editor']));
drop policy if exists organizations_editor_update on public.organizations;
create policy organizations_editor_update on public.organizations for update to authenticated using (public.has_any_role(array['super_admin','admin','recruitment_editor'])) with check (public.has_any_role(array['super_admin','admin','recruitment_editor']));

-- Public sees verified recruitment only. Editors can manage drafts; reviewers can verify.
drop policy if exists jobs_public_verified_read on public.jobs;
create policy jobs_public_verified_read on public.jobs for select to anon, authenticated using (verification_status = 'verified' and status <> 'draft' or public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer','content_reviewer','analyst']));
drop policy if exists jobs_editor_insert on public.jobs;
create policy jobs_editor_insert on public.jobs for insert to authenticated with check (public.has_any_role(array['super_admin','admin','recruitment_editor']) and verification_status <> 'verified');
drop policy if exists jobs_editor_update on public.jobs;
create policy jobs_editor_update on public.jobs for update to authenticated using (public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer'])) with check (public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer']));
drop policy if exists jobs_admin_delete on public.jobs;
create policy jobs_admin_delete on public.jobs for delete to authenticated using (public.has_any_role(array['super_admin','admin']));

-- Translations: public reads only for verified jobs; editors manage drafts.
drop policy if exists translations_public_read on public.job_translations;
create policy translations_public_read on public.job_translations for select to anon, authenticated using (exists(select 1 from public.jobs j where j.id=job_id and j.verification_status='verified' and j.status <> 'draft') or public.has_any_role(array['super_admin','admin','recruitment_editor','hindi_editor','content_reviewer','analyst']));
drop policy if exists translations_editor_write on public.job_translations;
create policy translations_editor_write on public.job_translations for all to authenticated using (public.has_any_role(array['super_admin','admin','recruitment_editor','hindi_editor'])) with check (public.has_any_role(array['super_admin','admin','recruitment_editor','hindi_editor']));

-- Details, sources and dates are readable only when the parent job is verified, unless staff.
create policy qualifications_read on public.job_qualifications for select to anon, authenticated using (exists(select 1 from public.jobs j where j.id=job_id and j.verification_status='verified') or public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer','analyst']));
create policy qualifications_manage on public.job_qualifications for all to authenticated using (public.has_any_role(array['super_admin','admin','recruitment_editor'])) with check (public.has_any_role(array['super_admin','admin','recruitment_editor']));
create policy age_rules_read on public.job_age_rules for select to anon, authenticated using (exists(select 1 from public.jobs j where j.id=job_id and j.verification_status='verified') or public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer','analyst']));
create policy age_rules_manage on public.job_age_rules for all to authenticated using (public.has_any_role(array['super_admin','admin','recruitment_editor'])) with check (public.has_any_role(array['super_admin','admin','recruitment_editor']));
create policy dates_read on public.job_dates for select to anon, authenticated using (exists(select 1 from public.jobs j where j.id=job_id and j.verification_status='verified') or public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer','analyst']));
create policy dates_manage on public.job_dates for all to authenticated using (public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer'])) with check (public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer']));
create policy sources_read on public.job_sources for select to anon, authenticated using (exists(select 1 from public.jobs j where j.id=job_id and j.verification_status='verified') or public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer','analyst']));
create policy sources_manage on public.job_sources for all to authenticated using (public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer'])) with check (public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer']));
create policy documents_read on public.job_documents for select to anon, authenticated using ((is_public = true and exists(select 1 from public.jobs j where j.id=job_id and j.verification_status='verified')) or public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer']));
create policy documents_manage on public.job_documents for all to authenticated using (public.has_any_role(array['super_admin','admin','recruitment_editor'])) with check (public.has_any_role(array['super_admin','admin','recruitment_editor']));
create policy verification_staff_read on public.verification_records for select to authenticated using (public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer','content_reviewer','analyst']));
create policy verification_reviewer_insert on public.verification_records for insert to authenticated with check (reviewer_id=auth.uid() and public.has_any_role(array['super_admin','admin','verification_officer']));
create policy verification_reviewer_update on public.verification_records for update to authenticated using (public.has_any_role(array['super_admin','admin','verification_officer'])) with check (public.has_any_role(array['super_admin','admin','verification_officer']));
create policy updates_public_read on public.job_updates for select to anon, authenticated using (exists(select 1 from public.jobs j where j.id=job_id and j.verification_status='verified') or public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer','analyst']));
create policy updates_manage on public.job_updates for all to authenticated using (public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer'])) with check (public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer']));
create policy exam_updates_public_read on public.exam_updates for select to anon, authenticated using (is_verified = true or public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer','analyst']));
create policy exam_updates_manage on public.exam_updates for all to authenticated using (public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer'])) with check (public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer']));

-- Private user-owned records.
create policy saved_jobs_owner_all on public.saved_jobs for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy applications_owner_all on public.applications for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy notification_preferences_owner_all on public.notification_preferences for all to authenticated using (user_id=auth.uid()) with check (user_id=auth.uid());
create policy notification_deliveries_owner_read on public.notification_deliveries for select to authenticated using (user_id=auth.uid());
create policy reports_public_insert on public.content_reports for insert to anon, authenticated with check (length(message) between 10 and 3000);
create policy reports_staff_all on public.content_reports for all to authenticated using (public.has_any_role(array['super_admin','admin','support_officer'])) with check (public.has_any_role(array['super_admin','admin','support_officer']));
create policy audit_staff_read on public.admin_audit_logs for select to authenticated using (public.has_any_role(array['super_admin','admin','analyst']));
create policy audit_staff_insert on public.admin_audit_logs for insert to authenticated with check (actor_id=auth.uid() and public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer']));

-- NOTE: create a private Supabase Storage bucket named `job-documents` separately.
-- Grant object upload/download only to authorized staff, and serve approved public files
-- through signed URLs or a carefully designed public-document delivery policy.

-- First super-admin setup: after creating your account, run this once with its auth UUID:
-- update public.profiles set role='super_admin' where id='YOUR-AUTH-USER-UUID';

-- 8) Private file storage policies -------------------------------------------
-- Create the `job-documents` bucket in Supabase Storage first and mark it PRIVATE.
drop policy if exists nationjob_staff_upload_documents on storage.objects;
create policy nationjob_staff_upload_documents on storage.objects
for insert to authenticated
with check (bucket_id = 'job-documents' and public.has_any_role(array['super_admin','admin','recruitment_editor']));
drop policy if exists nationjob_staff_read_documents on storage.objects;
create policy nationjob_staff_read_documents on storage.objects
for select to authenticated
using (bucket_id = 'job-documents' and public.has_any_role(array['super_admin','admin','recruitment_editor','verification_officer','analyst']));
drop policy if exists nationjob_staff_update_documents on storage.objects;
create policy nationjob_staff_update_documents on storage.objects
for update to authenticated
using (bucket_id = 'job-documents' and public.has_any_role(array['super_admin','admin','recruitment_editor']))
with check (bucket_id = 'job-documents' and public.has_any_role(array['super_admin','admin','recruitment_editor']));
drop policy if exists nationjob_staff_delete_documents on storage.objects;
create policy nationjob_staff_delete_documents on storage.objects
for delete to authenticated
using (bucket_id = 'job-documents' and public.has_any_role(array['super_admin','admin']));


-- 9) Explicit grants. RLS remains the enforcement layer for row-level access.
grant usage on schema public to anon, authenticated;
grant select on public.organizations, public.jobs, public.job_translations,
  public.job_qualifications, public.job_age_rules, public.job_dates,
  public.job_sources, public.job_documents, public.exam_updates to anon, authenticated;
grant select, insert, update, delete on all tables in schema public to authenticated;
grant insert on public.content_reports to anon;
grant usage, select on all sequences in schema public to authenticated;
